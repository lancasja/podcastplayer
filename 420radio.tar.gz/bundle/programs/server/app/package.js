(function(){// Cordova.depends({
// 	'org.apache.cordova.splashscreen': 'https://git-wip-us.apache.org/repos/asf/cordova-plugin-splashscreen.git',
// });

})();
